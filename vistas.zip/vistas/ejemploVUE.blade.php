<!doctype html>
<htmlm lang="es">
    <head>
        <title>Ejemplo de Vueee</title>
        <meta charset="UTF-8">
        <meta name="title" content="Título de la WEB">
        <meta name="description" content="Descripción de la WEB">
        <link href="http://dominio.com/hoja-de-estilos.css" rel="stylesheet" type="text/css"/>
    </head>
    <body>
    <div >

        <h1> funciona ......</h1>
        <example-component></example-component>
    </div>
    </body>
</htmlm>