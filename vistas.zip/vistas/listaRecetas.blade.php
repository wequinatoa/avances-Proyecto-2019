<html>
<head>
<body>
<div class="container">
    <li class="list-group">
        @foreach($listaRecetas as $receta)
            <ol class="list-group-item">
                {{$reto->nombre}}<br>
                {{$reto->cantidad}}<br>
                {{$reto->tiempo}}<br>
                ---------------------------
            </ol>
        @endforeach

    </li>
</div>
</body>
</head>
</html>